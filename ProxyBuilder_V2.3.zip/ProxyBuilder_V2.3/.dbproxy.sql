CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dbproxy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `dbproxy`;
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `timestamp` bigint(20) unsigned NOT NULL,
  `utilisateurs` varchar(20) NOT NULL,
  `ip_utilisateur` varchar(15) NOT NULL,
  `code` char(3) NOT NULL,
  `url` varchar(100) NOT NULL,
  `ping` int(6) NOT NULL,
  `bytes` bigint(15) NOT NULL,
  PRIMARY KEY (`timestamp`,`utilisateurs`,`ping`,`bytes`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `comptes`;
CREATE TABLE `comptes` (
  `login` varchar(20) NOT NULL,
  `mdp` char(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `comptes` (`login`, `mdp`) 
VALUES ('admin', MD5('admin'));
