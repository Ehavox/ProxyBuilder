====== ProxyBuilder_V2.3 =======
Développé par Ehavox

Description :
Ce programme permet la configuration automatisée du proxy Squid.

Lancement :
chmod +x ProxyBuilder_V2.3
./ProxyBuilder_V2.3


Instructions d'utilisation :
-Après la première exécution, tapez la commande "source ~/.bashrc" (met à jour les variables pour une réutilisation future)
-Le fichier `.parsing.php` est essentiel au bon fonctionnement du système : il gère l’enregistrement des journaux (logs). Ne le supprimez en aucun cas.
-Le fichier ProxyBuilder_V2.3 est une version exécutable datée. **Cette version expirera le 15/12/2025.


Remarques :
* Cette limitation temporelle vise à assurer une veille technologique continue ainsi qu’à respecter certaines conditions de propriété intellectuelle.
* Pour obtenir une mise à jour ou une nouvelle version, veuillez contacter l’auteur ou consulter le site.


Amélioration de la version 2.3 :
-Version améliorée de ProxyBuilder
-Option supplémentaire pour l'automatisation de tâches
-Amélioration graphique du site web de consultation des logs
-Vérification des input (partie base de données)
-Vérification au redémarrage