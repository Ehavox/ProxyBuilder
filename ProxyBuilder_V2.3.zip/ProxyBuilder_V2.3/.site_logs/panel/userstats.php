<?php
session_start();
date_default_timezone_set('Europe/Paris');

// Debug (à désactiver en prod)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connexion BDD
$conn = new mysqli("localhost", "user", "mdp", "dbname");
if ($conn->connect_error) die("Connexion échouée : " . $conn->connect_error);

// Filtres
$filterDate = (isset($_GET['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'])) ? $_GET['date'] : date("Y-m-d");
$filterUser = $_GET['user'] ?? '';
$filterURL = $_GET['url'] ?? '';
$conditions = [];

if ($filterDate) {
    $debutjour = strtotime($filterDate . " 00:00:00") * 1000;
    $finjour   = strtotime($filterDate . " 23:59:59") * 1000;
} else {
    $debutjour = strtotime(date("Y-m-d 00:00:00")) * 1000;
    $finjour   = strtotime(date("Y-m-d 23:59:59")) * 1000;
}

if ($filterUser) {
    $filterUserSafe = $conn->real_escape_string($filterUser);
    $conditions[] = "utilisateurs LIKE '%$filterUserSafe%'";
}
if ($filterURL) {
    $filterURLSafe = $conn->real_escape_string($filterURL);
    $conditions[] = "url LIKE '%$filterURLSafe%'";
}

// Requêtes TOP
$urlBytesResult = $conn->query("
    SELECT url, SUM(bytes) AS total_bytes 
    FROM logs 
    WHERE timestamp BETWEEN $debutjour AND $finjour 
    " . ($filterUser ? "AND utilisateurs = '$filterUserSafe'" : "") . "
    GROUP BY url 
    ORDER BY total_bytes DESC 
    LIMIT 20
");

$urlHitsResult = $conn->query("
    SELECT url, COUNT(*) AS hits 
    FROM logs 
    WHERE timestamp BETWEEN $debutjour AND $finjour 
    " . ($filterUser ? "AND utilisateurs = '$filterUserSafe'" : "") . "
    GROUP BY url 
    ORDER BY hits DESC 
    LIMIT 20
");

$ipResult = $conn->query("
    SELECT ip_utilisateur, SUM(bytes) AS total_bytes 
    FROM logs 
    WHERE timestamp BETWEEN $debutjour AND $finjour 
    " . ($filterUser ? "AND utilisateurs = '$filterUserSafe'" : "") . "
    GROUP BY ip_utilisateur 
    ORDER BY total_bytes DESC 
    LIMIT 20
");
?>

<!DOCTYPE html>
<html>

<head>
  <title>Statistiques utilisateur</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Design modernisé -->
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,600">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/x-icon" href="squideye.ico">

  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f5f7fa;
    }

    .top-bar {
      background: linear-gradient(90deg, #559985, #0931b6);
      color: white;
    }

    .w3-sidebar {
      background: #111827 !important;
      color: #e5e7eb !important;
    }

    .w3-sidebar a {
      color: #e5e7eb !important;
    }

    header {
      background: linear-gradient(90deg, #065f46, #047857);
      color: white;
      border-radius: 8px;
    }

    .stat-card {
      background: white;
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 8px 20px rgba(2, 6, 23, 0.08);
    }

    .stat-title {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 8px;
    }

    .url {
      font-weight: 600;
    }

    hr {
      margin: 12px 0;
    }
  </style>
</head>

<body class="w3-light-grey">

  <!-- BARRE TOP -->
  <div class="w3-top top-bar w3-padding">
    <div class="w3-bar">
      <a href="../index.php" class="w3-bar-item w3-large w3-round w3-button">Accueil</a>
    </div>
  </div>

  <!-- SIDEBAR -->
  <nav class="w3-sidebar w3-collapse w3-animate-left" style="width:300px;">
    <div class="w3-container w3-center w3-padding-32">
      <h4>Bienvenue</h4>
      <p>
        <?= htmlspecialchars($_SESSION['usrname'] ?? "Invité") ?>
      </p>
    </div>
    <hr>
    <a href="control_panel.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-gauge"></i> Tableau de
      bord</a><br>
    <a href="log.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-ticket"></i> Logs</a>
    <a href="userstats.php" class="w3-bar-item w3-round w3-button w3-dark-grey"><i class="fa fa-chart-line"></i>
      Statistiques
      utilisateur</a>
    <a href="utilisateurs.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-users"></i> Utilisateurs</a>
  </nav>

  <!-- CONTENU -->
  <div class="w3-main" style="margin-left:300px;margin-top:60px;">

    <header class="w3-container w3-center w3-padding-16" style="margin:16px;">
      <h3><i class="fa fa-user-chart"></i> Statistiques utilisateur</h3>
      <p>
        <?= htmlspecialchars($filterUser ?: "Tous les utilisateurs") ?> — <strong>
          <?= htmlspecialchars($filterDate) ?>
        </strong>
      </p>
    </header>

    <div class="w3-container" style="margin:16px;">

      <!-- FILTRES -->
      <form method="get" class="w3-margin-bottom" style="display:flex;flex-wrap:wrap;gap:8px;">
        <input class="w3-input w3-border" style="max-width:200px;" type="date" name="date"
          value="<?= htmlspecialchars($filterDate) ?>">
        <input class="w3-input w3-border" style="max-width:250px;" type="text" name="user"
          value="<?= htmlspecialchars($filterUser) ?>" placeholder="Utilisateur">
        <button class="w3-button w3-round w3-green" type="submit"><i class="fa fa-search"></i> Rechercher</button>

        <?php if ($filterDate || $filterUser): ?>
        <a href="userstats.php" class="w3-button w3-round w3-light-grey"><i class="fa fa-eraser"></i> Réinitialiser</a>
        <?php endif; ?>

        <a href="userstats.php" class="w3-button w3-round w3-blue"><i class="fa fa-sync"></i> Rafraîchir</a>
      </form>

      <!-- 3 COLONNES -->
      <div class="w3-row-padding">

        <!-- TOP URL CONSO -->
        <div class="w3-third w3-margin-bottom">
          <div class="stat-card">
            <h4 class="stat-title w3-text-cyan"><i class="fa fa-download"></i> <u>Top 10 URL les plus consommatrices</u></h4>
            <?php while ($row = $urlBytesResult->fetch_assoc()): ?>
            <p class="url">
              <?= htmlspecialchars($row['url']) ?>
            </p>
            <p>
              <?= number_format($row['total_bytes'] / 1_000_000, 2) ?> MB
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- TOP URL CONSULTÉES -->
        <div class="w3-third w3-margin-bottom">
          <div class="stat-card">
            <h4 class="stat-title"><i class="fa fa-eye"></i> <u>Top 10 URL les plus consultées</u></h4>
            <?php while ($row = $urlHitsResult->fetch_assoc()): ?>
            <p class="url">
              <?= htmlspecialchars($row['url']) ?>
            </p>
            <p>
              <?= number_format($row['hits']) ?> consultations
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- TOP IP CONSOMMATRICES -->
        <div class="w3-third w3-margin-bottom">
          <div class="stat-card">
            <h4 class="stat-title"><i class="fa fa-server"></i> <u>Top 10 IP consommatrices</u></h4>
            <h6 style="margin-top:-6px;color:#6b7280;">(Pour l'utilisateur sélectionné)</h6>
            <?php while ($row = $ipResult->fetch_assoc()): ?>
            <p class="url">
              <?= htmlspecialchars($row['ip_utilisateur']) ?>
            </p>
            <p>
              <?= number_format($row['total_bytes'] / 1_000_000, 2) ?> MB
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

      </div>

      <footer class="w3-container w3-light-grey w3-padding-16 w3-center" style="border-radius:8px;margin-top:16px;">
        © 2025 - Tableau de bord Proxy | EHAVOX
      </footer>

    </div>
  </div>

</body>

</html>