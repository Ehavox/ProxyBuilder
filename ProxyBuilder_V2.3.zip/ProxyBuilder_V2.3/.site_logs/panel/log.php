<?php
session_start();
date_default_timezone_set('Europe/Paris');

// affichage des erreurs pour debug (à désactiver en production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connexion BDD
$conn = new mysqli("localhost", "user", "mdp", "dbname");
if ($conn->connect_error) die("Connexion échouée : " . $conn->connect_error);

// Colonnes autorisées pour le tri
$allowedColumns = ['timestamp', 'ip_utilisateur', 'bytes'];
$column = in_array($_GET['sort'] ?? '', $allowedColumns) ? $_GET['sort'] : 'timestamp';
$order = (isset($_GET['order']) && $_GET['order'] === 'ASC') ? 'ASC' : 'DESC';
$nextOrder = $order === 'ASC' ? 'DESC' : 'ASC';

// Filtres
$filterDate = (isset($_GET['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'])) ? $_GET['date'] : date("Y-m-d");
$filterUser = $_GET['user'] ?? '';
$filterURL = $_GET['url'] ?? '';
$conditions = [];

if ($filterDate && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDate)) {
    // compare date based on timestamp (ms)
    $conditions[] = "DATE(FROM_UNIXTIME(timestamp / 1000)) = '" . $conn->real_escape_string($filterDate) . "'";
}
if ($filterUser !== '') {
    $filterUserSafe = $conn->real_escape_string($filterUser);
    $conditions[] = "utilisateurs LIKE '%$filterUserSafe%'";
}
if ($filterURL !== '') {
    $filterURLSafe = $conn->real_escape_string($filterURL);
    $conditions[] = "url LIKE '%$filterURLSafe%'";
}

$whereClause = $conditions ? "WHERE " . implode(" AND ", $conditions) : "";

// Pagination
$logsPerPage = 50;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $logsPerPage;

// Requête principale
$sql = "SELECT * FROM logs $whereClause ORDER BY $column $order LIMIT $logsPerPage OFFSET $offset";
$result = $conn->query($sql);

// Nombre total pour pagination
$countResult = $conn->query("SELECT COUNT(*) as total FROM logs $whereClause");
$totalLogs = $countResult ? intval($countResult->fetch_assoc()['total']) : 0;
$totalPages = max(1, ceil($totalLogs / $logsPerPage));

// Helper pour construire URLs de tri/pagination tout en conservant les filtres
function build_url(array $params) {
    $base = htmlspecialchars($_SERVER['PHP_SELF']);
    $qs = http_build_query(array_merge($_GET, $params));
    return $base . '?' . $qs;
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Logs du Proxy</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- W3.CSS + fonts + icons -->
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,600">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/x-icon" href="squideye.ico">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f5f7fa;
    }

    .top-bar {
      background: linear-gradient(90deg, #559985, #0931b6);
      color: white;
    }

    .w3-sidebar {
      background: #111827 !important;
      color: #e5e7eb !important;
    }

    .w3-sidebar a {
      color: #e5e7eb !important;
    }

    header {
      background: linear-gradient(90deg, #065f46, #047857);
      color: white;
      border-radius: 8px;
    }

    .container-card {
      background: #fff;
      border-radius: 10px;
      padding: 16px;
      box-shadow: 0 8px 20px rgba(2, 6, 23, 0.08);
    }

    .log-table th,
    .log-table td {
      text-align: center;
      vertical-align: middle;
    }

    .log-table thead th {
      font-weight: 600;
    }

    .status-200 {
      background-color: #ecfdf5;
    }

    .status-404,
    .status-500 {
      background-color: #fff1f2;
    }

    .status-other {
      background-color: #fff7ed;
    }

    .filter-input {
      max-width: 220px;
      display: inline-block;
      margin-right: 8px;
    }

    .small {
      font-size: 0.85rem;
      color: #6b7280;
    }

    .pagination .w3-button {
      margin: 2px;
    }

    .w3-table .url-cell {
      max-width: 400px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    @media (max-width: 800px) {
      .w3-third {
        width: 100% !important;
      }

      .filter-input {
        display: block;
        width: 100%;
        margin-bottom: 8px;
      }
    }
  </style>
</head>

<body class="w3-light-grey">

  <!-- navigation top -->
  <div class="w3-top top-bar w3-padding">
    <div class="w3-bar">
      <a href="../index.php" class="w3-bar-item w3-large w3-round w3-button">Accueil</a>
    </div>
  </div>

  <!-- menu gauche -->
  <nav class="w3-sidebar w3-collapse w3-animate-left" style="width:300px;" id="mySidebar">
    <div class="w3-container w3-center w3-padding-32">
      <h4>Bienvenue</h4>
      <p class="small">
        <?= htmlspecialchars($_SESSION['usrname'] ?? 'Invité') ?>
      </p>
    </div>
    <hr>
    <a href="control_panel.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-gauge"></i> Tableau de
      bord</a><br>
    <a href="log.php" class="w3-bar-item w3-button w3-round w3-dark-grey"><i class="fa fa-ticket"></i> Logs</a>
    <a href="userstats.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-chart-line"></i> Statistiques
      utilisateur</a>
    <a href="utilisateurs.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-users"></i> Utilisateurs</a>
  </nav>

  <!-- contenu principal -->
  <div class="w3-main" style="margin-left:300px;margin-top:60px;">

    <header class="w3-container w3-center w3-padding-16" style="margin: 0 16px 12px 16px;">
      <h3><i class="fa fa-magnifying-glass"></i> Logs du Proxy</h3>
      <p class="small">Affichage et recherche des logs — date sélectionnée : <strong>
          <?= htmlspecialchars($filterDate) ?>
        </strong></p>
    </header>

    <div class="w3-container" style="margin: 0 16px;">
      <div class="container-card">

        <!-- filtrage -->
        <form method="get" class="w3-margin-bottom" style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
          <input class="w3-input w3-border filter-input" type="date" name="date"
            value="<?= htmlspecialchars($filterDate) ?>" placeholder="Date">
          <input class="w3-input w3-border filter-input" type="text" name="user"
            value="<?= htmlspecialchars($filterUser) ?>" placeholder="Utilisateur">
          <input class="w3-input w3-border filter-input" type="text" name="url"
            value="<?= htmlspecialchars($filterURL) ?>" placeholder="Mot-clé dans l'URL">
          <input type="hidden" name="sort" value="<?= htmlspecialchars($column) ?>">
          <input type="hidden" name="order" value="<?= htmlspecialchars($order) ?>">
          <div style="display:flex; gap:8px; align-items:center;">
            <button class="w3-button w3-round w3-green" type="submit"><i class="fa fa-search"></i> Filtrer</button>
            <?php if ($filterDate || $filterUser || $filterURL): ?>
            <a href="log.php" class="w3-button w3-round w3-light-grey"><i class="fa fa-eraser"></i> Réinitialiser</a>
            <?php endif; ?>
            <a href="log.php" class="w3-button w3-round w3-blue"><i class="fa fa-sync"></i> Rafraîchir</a>
          </div>
        </form>

        <!-- tableau -->
        <div style="overflow-x:auto;">
          <table class="w3-table w3-bordered w3-striped w3-hoverable w3-white log-table" style="min-width:1000px;">
            <thead>
              <tr class="w3-dark-grey">
                <th>
                  <a
                    href="<?= build_url(['sort' => 'timestamp', 'order' => $column === 'timestamp' ? $nextOrder : 'DESC', 'page' => 1]) ?>">
                    Horodatage
                    <?= $column === 'timestamp' ? ($order === 'ASC' ? '↑' : '↓') : '' ?>
                  </a>
                </th>
                <th>Utilisateur</th>
                <th>
                  <a
                    href="<?= build_url(['sort' => 'ip_utilisateur', 'order' => $column === 'ip_utilisateur' ? $nextOrder : 'DESC', 'page' => 1]) ?>">
                    IP
                    <?= $column === 'ip_utilisateur' ? ($order === 'ASC' ? '↑' : '↓') : '' ?>
                  </a>
                </th>
                <th>Code</th>
                <th>URL</th>
                <th>Ping (ms)</th>
                <th>
                  <a
                    href="<?= build_url(['sort' => 'bytes', 'order' => $column === 'bytes' ? $nextOrder : 'DESC', 'page' => 1]) ?>">
                    Bytes
                    <?= $column === 'bytes' ? ($order === 'ASC' ? '↑' : '↓') : '' ?>
                  </a>
                </th>
              </tr>
            </thead>
            <tbody>
              <?php
            if ($result && $result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                // sécurité à l'affichage
                $userOut = htmlspecialchars($row['utilisateurs'] ?? '-');
                $ipOut = htmlspecialchars($row['ip_utilisateur'] ?? '-');
                $codeOut = intval($row['code'] ?? 0);
                $urlOut = htmlspecialchars($row['url'] ?? '-');
                $pingOut = htmlspecialchars($row['ping'] ?? '-');
                $bytesOut = intval($row['bytes'] ?? 0);
                $datetime = date("Y-m-d H:i:s", (int)($row['timestamp'] / 1000));

                // classes de statut
                if ($codeOut === 200) $rowClass = 'status-200';
                elseif (in_array($codeOut, [404, 500])) $rowClass = 'status-404';
                else $rowClass = 'status-other';

                echo "<tr class='{$rowClass}'>
                        <td>" . htmlspecialchars($datetime) . "</td>
                        <td>{$userOut}</td>
                        <td>{$ipOut}</td>
                        <td>{$codeOut}</td>
                        <td class='url-cell' title=\"" . $urlOut . "\">{$urlOut}</td>
                        <td>{$pingOut}</td>
                        <td>" . number_format($bytesOut) . "</td>
                      </tr>";
              }
            } else {
              echo "<tr><td colspan='7' class='small'>Aucun log trouvé.</td></tr>";
            }
            ?>
            </tbody>
          </table>
        </div>

        <!-- pagination -->
        <div class="w3-center w3-padding-16">
          <div class="w3-bar pagination">
            <?php
          // Affiche un ensemble de pages autour de la page courante pour ne pas surcharger l'affichage
          $start = max(1, $page - 4);
          $end = min($totalPages, $page + 4);
          if ($page > 1) {
            echo '<a href="' . build_url(['page' => $page - 1]) . '" class="w3-button w3-light-grey"><i class="fa fa-chevron-left"></i></a>';
          }
          for ($i = $start; $i <= $end; $i++) {
            $cls = $i == $page ? 'w3-green' : 'w3-light-grey';
            echo '<a href="' . build_url(['page' => $i]) . '" class="w3-button ' . $cls . '">' . $i . '</a>';
          }
          if ($page < $totalPages) {
            echo '<a href="' . build_url(['page' => $page + 1]) . '" class="w3-button w3-light-grey"><i class="fa fa-chevron-right"></i></a>';
          }
          ?>
          </div>
          <p class="small">Page
            <?= $page ?> /
            <?= $totalPages ?> —
            <?= number_format($totalLogs) ?> logs
          </p>
        </div>

      </div> <!-- container-card -->
    </div> <!-- container -->

    <footer class="w3-container w3-light-grey w3-padding-16" style="margin: 16px;">
      <p>© 2025 - Tableau de bord Proxy | EHAVOX</p>
    </footer>

  </div> <!-- main -->
</body>

</html>