<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "user", "mdp", "dbname");
if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);

// Ajouter un utilisateur
if (isset($_POST['add_user'])) {
    $login = $conn->real_escape_string($_POST['login']);
    $mdp = md5($_POST['mdp']);
    $conn->query("INSERT INTO comptes (login, mdp) VALUES ('$login', '$mdp')");
}

// Supprimer un utilisateur
if (isset($_POST['delete_user'])) {
    $login = $conn->real_escape_string($_POST['login']);
    $password = md5($_POST['password']);
    $check = $conn->query("SELECT mdp FROM comptes WHERE login='$login'");
    if ($check && $check->num_rows > 0) {
        $conn->query("DELETE FROM comptes WHERE login='$login'");
    } else {
        echo "<script>alert('Mot de passe incorrect.');</script>";
    }
}

// Modifier un mot de passe
if (isset($_POST['update_pwd'])) {
    $login = $conn->real_escape_string($_POST['login']);
    $oldpwd = md5($_POST['oldpwd']);
    $newpwd = md5($_POST['newpwd']);
    $check = $conn->query("SELECT mdp FROM comptes WHERE login='$login'");
    if ($check && $check->num_rows > 0) {
        $conn->query("UPDATE comptes SET mdp='$newpwd' WHERE login='$login'");
    } else {
        echo "<script>alert('Ancien mot de passe incorrect.');</script>";
    }
}

$result = $conn->query("SELECT login FROM comptes ORDER BY login ASC");
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestion des utilisateurs</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,600">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/x-icon" href="squideye.ico">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f5f7fa;
    }

    .top-bar {
      background: linear-gradient(90deg, #559985, #0931b6);
      color: white;
    }

    .w3-sidebar {
      background: #111827 !important;
      color: #e5e7eb !important;
    }

    .w3-sidebar a {
      color: #e5e7eb !important;
    }

    header {
      background: linear-gradient(90deg, #065f46, #047857);
      color: white;
      border-radius: 8px;
    }

    .card {
      background: white;
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 8px 20px rgba(2, 6, 23, 0.08);
    }

    .table-actions button {
      margin-right: 5px;
    }
  </style>
  <script>
    function confirmDelete(login) {
      let pwd = prompt("Entrez le mot de passe de '" + login + "' :");
      if (pwd !== null) {
        let form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `<input type="hidden" name="login" value="${login}">` +
          `<input type="hidden" name="password" value="${pwd}">` +
          `<input type="hidden" name="delete_user">`;
        document.body.appendChild(form);
        form.submit();
      }
    }
    function confirmPasswordChange(login) {
      let oldpwd = prompt("Ancien mot de passe :");
      if (oldpwd !== null) {
        let newpwd = prompt("Nouveau mot de passe :");
        if (newpwd !== null) {
          let form = document.createElement('form');
          form.method = 'POST';
          form.innerHTML = `<input type="hidden" name="login" value="${login}">` +
            `<input type="hidden" name="oldpwd" value="${oldpwd}">` +
            `<input type="hidden" name="newpwd" value="${newpwd}">` +
            `<input type="hidden" name="update_pwd">`;
          document.body.appendChild(form);
          form.submit();
        }
      }
    }
  </script>
</head>

<body class="w3-light-grey">
  <div class="w3-top top-bar w3-padding">
    <a href="../index.php" class="w3-bar-item w3-large w3-round w3-button">Accueil</a>
  </div>
  <nav class="w3-sidebar w3-collapse w3-animate-left" style="width:300px;">
    <div class="w3-container w3-center w3-padding-32">
      <h4>Bienvenue</h4>
      <p>
        <?= htmlspecialchars($_SESSION['usrname'] ?? "Invité") ?>
      </p>
    </div>
    <hr>
    <a href="control_panel.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-gauge"></i> Tableau de
      bord</a><br>
    <a href="log.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-ticket"></i> Logs</a><br>
    <a href="userstats.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-chart-line"></i> Statistiques
      utilisateur</a><br>
    <a href="utilisateurs.php" class="w3-bar-item w3-round w3-button w3-dark-grey"><i class="fa fa-users"></i>
      Utilisateurs</a>
  </nav>
  <div class="w3-main" style="margin-left:300px;margin-top:60px;">
    <header class="w3-container w3-center w3-padding-16" style="margin:16px;">
      <h3><i class="fa fa-users"></i> Gestion des utilisateurs</h3>
    </header>
    <div class="w3-container" style="margin:16px;">
      <div class="card w3-margin-bottom">
        <h4><i class="fa fa-user-plus"></i> Ajouter un utilisateur</h4>
        <form method="post">
          <input class="w3-input w3-border" type="text" name="login" placeholder="Nom d'utilisateur" required>
          <input class="w3-input w3-border" type="password" name="mdp" placeholder="Mot de passe" required>
          <button class="w3-button w3-green w3-round w3-margin-top" name="add_user"><i class="fa fa-plus"></i>
            Ajouter</button>
        </form>
      </div>
      <div class="card">
        <h4><i class="fa fa-users"></i> Liste des utilisateurs</h4>
        <table class="w3-table w3-bordered w3-striped w3-hoverable">
          <tr>
            <th>Nom d'utilisateur</th>
            <th>Actions</th>
          </tr>
          <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td>
              <?= htmlspecialchars($row['login']) ?>
            </td>
            <td class="table-actions">
              <button class="w3-button w3-round w3-red w3-small" onclick="confirmDelete('<?= $row['login'] ?>')"><i
                  class="fa fa-trash"></i></button>
              <button class="w3-button w3-round w3-blue w3-small"
                onclick="confirmPasswordChange('<?= $row['login'] ?>')"><i class="fa fa-sync"></i></button>
            </td>
          </tr>
          <?php endwhile; ?>
        </table>
      </div>
    </div>
    <footer class="w3-container w3-light-grey w3-padding-16 w3-center" style="border-radius:8px;margin-top:16px;">
      © 2025 - Tableau de bord Proxy | EHAVOX
    </footer>
  </div>
</body>

</html>