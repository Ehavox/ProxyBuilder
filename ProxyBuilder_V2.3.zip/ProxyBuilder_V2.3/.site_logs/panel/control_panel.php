<?php
// Nouvelle version graphique modernisée en gardant la même disposition et les mêmes paramètres
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$debutjour = strtotime(date("Y-m-d 00:00:00")) * 1000;
$finjour = strtotime(date("Y-m-d 23:59:59")) * 1000;
$jour = date('d-m-Y');

// Connexion à la BDD
$conn = new mysqli("localhost", "user", "mdp", "dbname");
if ($conn->connect_error) die("Connexion échouée : " . $conn->connect_error);

$urlBytesResult = $conn->query("SELECT url, SUM(bytes) as total_bytes FROM logs WHERE timestamp > $debutjour AND timestamp < $finjour GROUP BY url ORDER BY total_bytes DESC LIMIT 5");
$urlHitsResult = $conn->query("SELECT url, COUNT(*) as hits FROM logs WHERE timestamp > $debutjour AND timestamp < $finjour GROUP BY url ORDER BY hits DESC LIMIT 5");
$ipResult = $conn->query("SELECT ip_utilisateur, SUM(bytes) as total_bytes FROM logs WHERE timestamp > $debutjour AND timestamp < $finjour GROUP BY ip_utilisateur ORDER BY total_bytes DESC LIMIT 5");
$userActiveResult = $conn->query("SELECT utilisateurs, COUNT(*) as total_requests FROM logs WHERE timestamp > $debutjour AND timestamp < $finjour GROUP BY utilisateurs ORDER BY total_requests DESC LIMIT 5");
$userConso = $conn->query("SELECT utilisateurs, SUM(bytes) as total_conso FROM logs WHERE timestamp > $debutjour AND timestamp < $finjour GROUP BY utilisateurs ORDER BY total_conso DESC LIMIT 5");
$urlblocks = $conn->query("SELECT url, COUNT(*) as hits FROM logs WHERE timestamp > $debutjour AND timestamp < $finjour AND utilisateurs = '-' GROUP BY url ORDER BY hits DESC LIMIT 5");
?>
<!DOCTYPE html>
<html>

<head>
  <title>Tableau de bord</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,600">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="icon" type="image/x-icon" href="squideye.ico">
  <style>
    body {
      font-family: "Poppins", sans-serif;
    }

    .dashboard-card {
      min-height: 160px;
      border-radius: 12px;
      transition: 0.25s;
      background: #fff;
      padding: 15px;
    }

    .dashboard-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    .w3-stat-title {
      font-size: 16px;
      font-weight: 600;
    }

    .w3-stat-value {
      font-size: 20px;
      margin-top: 8px;
      font-weight: 600;
    }

    .w3-sidebar {
      background: #111827 !important;
      color: #e5e7eb !important;
    }

    .w3-sidebar a {
      color: #ecf0f1 !important;
    }

    .top-bar {
      background: linear-gradient(90deg, #559985, #0931b6);
      color: white;
    }

    header {
      background: linear-gradient(90deg, #065f46, #047857);
      color: white;
      border-radius: 8px;
    }
  </style>
</head>

<body class="w3-light-grey">

  <div class="w3-top top-bar w3-padding">
    <a href="../index.php" class="w3-bar-item w3-large w3-round w3-button">Accueil</a>
  </div>

  <nav class="w3-sidebar w3-collapse w3-animate-left" style="width:300px;" id="mySidebar">
    <div class="w3-container w3-center w3-padding-32">
      <h4>Bienvenue</h4>
      <p>
        <?= $_SESSION['usrname']; ?>
      </p>
    </div>
    <hr>
    <a href="control_panel.php" class="w3-bar-item w3-round w3-dark-grey w3-button"><i class="fa fa-gauge"></i> Tableau
      de
      bord</a><br>
    <a href="log.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-ticket"></i> Logs</a>
    <a href="userstats.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-chart-line"></i> Statistiques
      utilisateur</a>
    <a href="utilisateurs.php" class="w3-bar-item w3-round w3-button"><i class="fa fa-users"></i> Utilisateurs</a>
  </nav>

  <div class="w3-main" style="margin-left:300px;margin-top:60px;">
    <header class="w3-container w3-center w3-padding-24">
      <h3><i class="fa fa-gauge"></i> Tableau de bord</h3>
      <h5>(Aujourd'hui)</h5>
    </header>

    <div class="w3-container w3-padding">
      <div class="w3-row-padding">

        <!-- TOP 5 URL PAR CONSO -->
        <div class="w3-third w3-margin-bottom">
          <div class="dashboard-card w3-border w3-center">
            <h4 class="w3-stat-title">Top 5 URL les plus consommatrices</h4>
            <?php while($row = $urlBytesResult->fetch_assoc()): ?>
            <p class="w3-stat-value w3-text-teal">
              <?= htmlspecialchars($row['url']) ?>
            </p>
            <p><i class="fa fa-download"></i>
              <?= number_format($row['total_bytes']/1000000) ?> MB
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- TOP USERS CONSOMMATION -->
        <div class="w3-third w3-margin-bottom">
          <div class="dashboard-card w3-border w3-center">
            <h4 class="w3-stat-title">Top 5 utilisateurs les plus consommateurs</h4>
            <?php while($row = $userConso->fetch_assoc()): ?>
            <p class="w3-stat-value w3-text-green">
              <?= htmlspecialchars($row['utilisateurs']) ?>
            </p>
            <p><i class="fa fa-exchange"></i>
              <?= number_format($row['total_conso']/1000000) ?> MB
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- TOP IP CONSOMMATION -->
        <div class="w3-third w3-margin-bottom">
          <div class="dashboard-card w3-border w3-center">
            <h4 class="w3-stat-title">Top 5 IP les plus consommatrices</h4>
            <?php while($row = $ipResult->fetch_assoc()): ?>
            <p class="w3-stat-value w3-text-purple">
              <?= htmlspecialchars($row['ip_utilisateur']) ?>
            </p>
            <p><i class="fa fa-server"></i>
              <?= number_format($row['total_bytes']/1000000) ?> MB
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- TOP UTILISATEURS ACTIFS -->
        <div class="w3-third w3-margin-bottom">
          <div class="dashboard-card w3-border w3-center">
            <h4 class="w3-stat-title">Top 5 utilisateurs les plus actifs</h4>
            <?php while($row = $userActiveResult->fetch_assoc()): ?>
            <p class="w3-stat-value w3-text-blue">
              <?= htmlspecialchars($row['utilisateurs']) ?>
            </p>
            <p><i class="fa fa-chart-column"></i>
              <?= number_format($row['total_requests']) ?> requêtes
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- TOP URL CONSULTÉES -->
        <div class="w3-third w3-margin-bottom">
          <div class="dashboard-card w3-border w3-center">
            <h4 class="w3-stat-title">Top 5 URL les plus consultées</h4>
            <?php while($row = $urlHitsResult->fetch_assoc()): ?>
            <p class="w3-stat-value w3-text-orange">
              <?= htmlspecialchars($row['url']) ?>
            </p>
            <p><i class="fa fa-eye"></i>
              <?= number_format($row['hits']) ?> consultations
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

        <!-- URL BLOQUÉES -->
        <div class="w3-third w3-margin-bottom">
          <div class="dashboard-card w3-border w3-center">
            <h4 class="w3-stat-title">Top 5 URL bloquées</h4>
            <?php while($row = $urlblocks->fetch_assoc()): ?>
            <p class="w3-stat-value w3-text-red">
              <?= htmlspecialchars($row['url']) ?>
            </p>
            <p><i class="fa fa-ban"></i>
              <?= number_format($row['hits']) ?> blocage
            </p>
            <hr>
            <?php endwhile; ?>
          </div>
        </div>

      </div>
    </div>

    <footer class="w3-container w3-light-grey w3-padding-16 w3-center">
      <p>© 2025 - Tableau de bord Proxy | EHAVOX</p>
    </footer>
  </div>

</body>

</html>