<?php
session_start();
$erreur_login = false;

// Traitement du formulaire de connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servername = "localhost";
    $username = "user";
    $password = "mdp";
    $dbname = "dbname";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connexion échouée: " . $conn->connect_error);
    }

    $login = $_POST['usrname'];
    $mdp = md5($_POST['passwd']);
    $sql = "SELECT * FROM comptes WHERE login = ? AND mdp = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $login, $mdp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $_SESSION['usrname'] = $login;
        $redirectPage = $_POST['redirect_to'] ?? 'panel/control_panel.php';
        header("Location: $redirectPage");
        exit;
    } else {
        $erreur_login = true;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>PROXY - VIEWER</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="squideye.ico">
    <style>
        body,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-family: "Lato", sans-serif;
        }

        .w3-bar,
        h1,
        button {
            font-family: "Montserrat", sans-serif;
        }

        .fa-gamepad,
        .fa-comments {
            font-size: 200px;
        }
    </style>
</head>

<body>
    <!-- NAVBAR -->
    <div class="w3-top">
        <div class="w3-bar w3-asphalt w3-card w3-left-align w3-large">
            <a href="index.php" class="w3-bar-item w3-round w3-button w3-padding-large w3-white">Accueil</a>
            <a onclick="openLoginModal('panel/control_panel.php')"
                class="w3-bar-item w3-button w3-hide-small w3-round w3-padding-large w3-hover-white">Logs</a>
            <button class="w3-bar-item w3-button w3-round w3-right w3-padding-large" onclick="w3_open()">
                <i class="fa fa-bars"></i>
            </button>
        </div>
    </div>
    <!-- SIDEBAR -->
    <nav class="w3-sidebar w3-bar-block w3-card w3-animate-right w3-asphalt"
        style="display:none; right:0; top:0; height:100%; width:250px; position:fixed; z-index:1000;" id="mySidebar">

        <!-- Bouton fermer -->
        <button onclick="w3_close()" class="w3-bar-item w3-round w3-button w3-large w3-right-align">&times;</button>
        <a href="index.php" class="w3-bar-item w3-round w3-button w3-sand">🏠 Accueil</a>
        <a href="about.html" class="w3-bar-item w3-round w3-button">ℹ️ À propos</a>

    </nav>
    <!-- SCRIPT -->
    <script>
        function w3_open() {
            document.getElementById("mySidebar").style.display = "block";
        }

        function w3_close() {
            document.getElementById("mySidebar").style.display = "none";
        }
    </script>

    <!-- HEADER -->
    <header class="w3-container w3-olive w3-center" style="padding:115px 16px">
        <img src="squideye.png" alt="Squid Proxy Logo" class="w3-image w3-margin-top w3-center w3-animate-opacity"
            style="width:150px;display:block;margin-left:auto;margin-right:auto;">
        <h1 class="w3-margin w3-jumbo">Squid Proxy Monitor</h1>
        <p class="w3-xlarge">Bienvenue sur la page web du serveur proxy</p>
        <button onclick="openLoginModal('panel/control_panel.php')"
            class="w3-button w3-black w3-round w3-padding-large w3-large w3-margin-top">Connexion</button>

        <!-- MODAL LOGIN -->
        <div id="id01" class="w3-modal" style="z-index:9999;">
            <div class="w3-modal-content w3-sand w3-card-4 w3-animate-zoom" style="max-width:600px">
                <div class="w3-center"><br>
                    <span onclick="document.getElementById('id01').style.display='none'"
                        class="w3-button w3-circle w3-xlarge w3-transparent w3-display-topright" title="Fermer">×</span>
                    <img src="profile.png" alt="Authentification" style="width:30%" class="w3-circle w3-margin-top">
                </div>

                <form class="w3-container" action="" method="post">
                    <div class="w3-section">
                        <label><b>Nom d'utilisateur</b></label>
                        <input class="w3-input w3-border w3-margin-bottom" type="text" placeholder="Utilisateur"
                            name="usrname" required>
                        <label><b>Mot de passe</b></label>
                        <input class="w3-input w3-border" type="password" placeholder="Mot de passe" name="passwd"
                            required>

                        <!-- Champ caché pour la redirection -->
                        <input type="hidden" name="redirect_to" id="redirect_to_input" value="panel/control_panel.php">

                        <button class="w3-button w3-round w3-block w3-green w3-section w3-padding"
                            type="submit">Login</button>
                    </div>
                </form>

                <div class="w3-container w3-border-top w3-padding-16 w3-light-grey">
                    <button onclick="document.getElementById('id01').style.display='none'" type="button"
                        class="w3-button w3-round w3-red">Annuler</button>
                </div>
            </div>
        </div>
    </header>

    <!-- CONTENU PRINCIPAL -->
    <div class="w3-row-padding w3-white w3-padding-64 w3-container">
        <div class="w3-content">
            <div class="w3-twothird">
                <h1><i>Gardez un œil sur le trafic du proxy</i></h1>
                <h4 class="w3-padding-16">
                    ➩ Complétion des logs dans la base de données toutes les (<i>cron manquant, rendez-vous sur le
                        panel</i>).
                </h4>
                <p class="w3-text-grey">
                    Ajout automatique des logs consultables via
                    <a href="#" onclick="openLoginModal('panel/control_panel.php')">cette page</a>.<br>
                    Système de gestion des doublons.<br>
                    Ajout/Suppression d'utilisateurs d'administration
                </p>
            </div>
            <div class="w3-third w3-center">
                <i class="fa fa-database" style="font-size:170px;color:rgb(190, 157, 9);"></i>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="w3-container w3-blue-gray w3-padding-64 w3-center">
        <p>© 2025 - EHAVOX PROXY</p>

        <div class="w3-margin-top">
            <a href="https://github.com/Ehavox" target="_blank"
                class="w3-button w3-round w3-black w3-padding-large w3-margin-right">
                GitHub
            </a>

            <a href="https://blog.ehvz-portfolio-vps.fr" target="_blank"
                class="w3-button w3-round w3-black w3-padding-large">
                Site Web
            </a>
        </div>
    </footer>


    <?php if ($erreur_login): ?>
    <script>
        alert("Nom d’utilisateur ou mot de passe incorrect");
        document.getElementById('id01').style.display = 'block';
    </script>
    <?php endif; ?>

    <script>
        function openLoginModal(targetPage) {
            document.getElementById('redirect_to_input').value = targetPage;
            document.getElementById('id01').style.display = 'block';
        }
    </script>
</body>

</html>