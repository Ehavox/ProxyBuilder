#!/usr/bin/php

<?php
// Définition des paramètres de la DB
$serveur = 'localhost';
$dbnom = 'dbproxy';
$user = 'user';
$mdp = 'password';

// Connexion à la base distante
$conn = new mysqli($serveur, $user, $mdp, $dbnom);

// Erreur si échec
if ($conn->connect_error) {
	die("Connexion échouée: " . $conn->connect_error);
}
// Lire le fichier des logs
foreach (file('/var/log/squid/access.log') as $s1) {
	$s2 = preg_replace('/\s+/', ' ', $s1);						// Avoir qu'un espace entre les arguments
	$t1 = explode(' ', $s2);									// Découpe les champs de la ligne en table
	$code_http = isset($t1[3]) ? substr($t1[3], 11, 3) : "000";	// Permet d'obtenir le code HTTP (récupère le contenu après le "/" (TCP_MISS/200))

	if (isset($t1[0]) && is_numeric($t1[0])) {					// Vérifie si le Timestamp est un float
		$timestamp_float = (float)$t1[0];						// Récupération du timestamp (avec son décimal)
		$timestamp = $timestamp_float * 1000;					// Multiplication x 1000 du timestamp (pour l'obtenir en entier)
	} else {
		continue;
	}
	// Requête d'insertion
	$check = $conn->prepare("SELECT count(*) from exemple where timestamp = ? and utilisateurs = ? and ip_utilisateur = ? and code = ? and url = ? and ping = ? and bytes = ?");
	$check->bind_param("issssis", $timestamp, $t1[7], $t1[2], $code_http, $t1[6], $t1[1], $t1[4]);
	$check->execute();
	$check->bind_result($count);
	$check->fetch();
	$check->close();
	if ($count == 0) {
		$stmt = $conn->prepare("INSERT IGNORE INTO exemple (timestamp, utilisateurs, ip_utilisateur, code, url, ping, bytes) VALUES (?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("issssis", $timestamp, $t1[7], $t1[2], $code_http, $t1[6], $t1[1], $t1[4]);
//	$t1[0]		// Timestamp, secondes depuis 01/01/1970 01:00 AM
//	$t1[1]		// Ping
//	$t1[2]		// IP utilisateur
//	$t1[4]		// Bytes consommés
//	$t1[6]		// URL
//	$t1[7]		// Utilisateur
//	$code_http	// Code HTTP

		$stmt->execute();
		}
}
?>
